# CC-12-git-for-labs

This repository contains all files necessary to complete Coding Club's tutorial on using GitHub as a lab.

Tutorial available here https://ourcodingclub.github.io/2017/05/15/git-for-labs.html

Data available from the Living Planet Index http://www.livingplanetindex.org/home/index

Check out https://ourcodingclub.github.io/workshop/ to learn how you can get involved!

We would love to hear your feedback on the tutorial, whether you did it at a Coding Club workshop or online: 
https://www.surveymonkey.co.uk/r/2P9R58J

This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/).

[![License: CC BY-SA 4.0](https://licensebuttons.net/l/by-sa/4.0/80x15.png)](https://creativecommons.org/licenses/by-sa/4.0/)
